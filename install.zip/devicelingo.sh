# Look at the device model
device_model=$(getprop ro.product.model)

# Define the name of the device
case "$device_model" in
    "TB128FU")
        device_name="XiaoXin Pad 2022"
        ;;
    "TB132FU")
        device_name="XiaoXin Pad Pro 2022"  # MediaTek
        ;;
    "TB138FC")
        device_name="XiaoXin Pad Pro 2022"  # Snapdragon
        ;;
    "TB371FC")
        device_name="XiaoXin Pad Pro 12.7"
        ;;
    "J716F")
        device_name="XiaoXin Pad Pro 2021"
        ;;
    "TB9707F")
        device_name="Legion Y700 (2022)"
        ;;
    "TB320FC")
        device_name="Legion Y700 (2023)"
        ;;    
    "TB331FC")
        device_name="XiaoXin Pad 2024"
        ;;
    *)
        # If the device is not in the list, do nothing
        device_name=""
        ;;
esac

if [ -n "$device_name" ]; then
    ui_print "╠ ▪️ Successfully assigned a device name: $device_name."
    echo "ro.odm.lenovo.series=$device_name" >> $MODPATH/system.prop
    echo "ro.zuk.product.market=$device_name" >> $MODPATH/system.prop
    echo "ro.product.display=$device_name" >> $MODPATH/system.prop
else
    ui_print "╠ ▪️ Latin device name not assigned: $device_model is missing in the list. Please contact @layryz (TG)."
fi