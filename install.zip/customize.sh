UM=1
SKIPUNZIP=1

RM_RF() {
    rm -rf $MODPATH/files 2>/dev/null
}

MODPRINT() {
    ui_print ""
    ui_print "╔═══╗─╔╗╔╗─╔══╗╔════╗╔═══╗─╔══╗─╔═╮─╭╗─╔══╗╔╗──╔══╗╔════╗╔══╗╔═══╗"
    ui_print "╚═╗─║─║║║║─╚╗╔╝╚═╗╔═╝║╔═╗║─║╔╗║─║║╰╮║║─║╔═╝║║──║╔╗║╚═╗╔═╝║╔╗║║╔═╗║"
    ui_print "─╔╝╔╝─║║║║──║║───║║──║╚═╝║─║╚╝║─║╭╮╰╯║─║╚═╗║║──║╚╝║──║║──║║║║║╚═╝║"
    ui_print "╔╝╔╝──║║║║──║║───║║──║╔╗╔╝─║╔╗║─║║╰╮║║─╚═╗║║║──║╔╗║──║║──║║║║║╔╗╔╝"
    ui_print "║─╚═╗─║╚╝║─╔╝╚╗──║║──║║║║──║║║║─║║─║║║─╔═╝║║╚═╗║║║║──║║──║╚╝║║║║║─"
    ui_print "╚═══╝─╚══╝─╚══╝──╚╝──╚╝╚╝──╚╝╚╝─╚╯─╰━╝─╚══╝╚══╝╚╝╚╝──╚╝──╚══╝╚╝╚╝─"
    ui_print "                       𝙱𝚢 𝙻𝚎𝚢𝚛𝚂𝚑𝚛𝚘𝚞𝚍; 𝚃𝙶: @𝚕𝚊𝚢𝚛𝚢𝚣               "
    ui_print "- Model: $(getprop ro.product.model) "
    ui_print ""
    MODEXTRACT
    ui_print ""
    ui_print "- NOTE -"
    ui_print "• If you have problems with an unwanted system locale being forcibly installed on your device, contact @layryz (TG) for help"
    ui_print "• When installing the module, the system locale will be forcibly changed to \"ru-RU\""
    ui_print ""
    MODADDON

    ui_print ""
    MODPERM
}

MODEXTRACT() {
    ui_print "- Extracting module files"
    unzip -o "$ZIPFILE" module.prop -d $MODPATH >&2
    unzip -o "$ZIPFILE" system.prop -d $MODPATH >&2
    unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
    unzip -o "$ZIPFILE" 'files/*' -d $MODPATH >&2
}


MODADDON() {
    codename_check

    # Check if the device requires additional patching for module operation
    if [ "$(getprop ro.product.device)" = "TB371FC" ]; then
        ui_print "╠ ▪️ A device has been detected that requires additional patching for module operation."
        if [ "$(settings get system system_locales)" != "ru-RUzhzh" ]; then
            su -c settings put system system_locales "ru-RUzhzh"
            ui_print "╠ ▪️ The value for the fix has been successfully set!"
            ui_print ""
            ui_print "• Thanks to todesengel131, VLAD S, changing and others for providing the new fix."
        else
            ui_print "╠ ▪️ The value to fix is already present in the system."
        fi
    else
        # For devices without locale installation issues
        if [ "$(settings get system system_locales)" != "ru-RU" ]; then
            su -c settings put system system_locales "ru-RU"
            ui_print "╠ ▪️ Third-party system locale detected, setting value to \"ru-RU\""
        fi
    fi

    sleep 3
    ui_print ""
    ui_print "- Successful installation!"
}

# Additional devices-specific overlays to prevent problems
codename_check() {
    if [ "$(getprop ro.product.device)" = "TB371FC" ]; then
        cp -rf $MODPATH/files/additapk/* $MODPATH/system/product/overlay/
        cp -rf $MODPATH/files/vendor/* $MODPATH/system/vendor/
        cp -rf $MODPATH/files/system.prop $MODPATH
        ui_print "╠ ▪️ This device uses a backup camera overlay for further correct operation."
    fi
    if [ "$(getprop ro.product.device)" = "J716F" ]; then
        rm -f $MODPATH/system/product/overlay/ZuiCamera.apk
        ui_print "╠ ▪️ This device has the camera translated (according to the users), the standard translation is used."
    fi
}


MODPERM() {
    set_perm_recursive $MODPATH 0 0 0755 0644
}

MODSET() {
    sed -i "/description=/c description=${TEXT1}" $MODPATH/module.prop
}


if [ ! "$SKIPUNZIP" = "0" ] ; then
    set -x
    MODPRINT
else
    set +x
    abort
fi

RM_RF
