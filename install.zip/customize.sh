UM=1
SKIPUNZIP=1

RM_RF() {
    rm -rf $MODPATH/files 2>/dev/null
}

MODPRINT() {
    ui_print ""
    ui_print "╔═══╗─╔╗╔╗─╔══╗╔════╗╔═══╗─╔══╗─╔═╮─╭╗─╔══╗╔╗──╔══╗╔════╗╔══╗╔═══╗"
    ui_print "╚═╗─║─║║║║─╚╗╔╝╚═╗╔═╝║╔═╗║─║╔╗║─║║╰╮║║─║╔═╝║║──║╔╗║╚═╗╔═╝║╔╗║║╔═╗║"
    ui_print "─╔╝╔╝─║║║║──║║───║║──║╚═╝║─║╚╝║─║╭╮╰╯║─║╚═╗║║──║╚╝║──║║──║║║║║╚═╝║"
    ui_print "╔╝╔╝──║║║║──║║───║║──║╔╗╔╝─║╔╗║─║║╰╮║║─╚═╗║║║──║╔╗║──║║──║║║║║╔╗╔╝"
    ui_print "║─╚═╗─║╚╝║─╔╝╚╗──║║──║║║║──║║║║─║║─║║║─╔═╝║║╚═╗║║║║──║║──║╚╝║║║║║─"
    ui_print "╚═══╝─╚══╝─╚══╝──╚╝──╚╝╚╝──╚╝╚╝─╚╯─╰━╝─╚══╝╚══╝╚╝╚╝──╚╝──╚══╝╚╝╚╝─"
    ui_print "                       𝙱𝚢 𝙻𝚎𝚢𝚛𝚂𝚑𝚛𝚘𝚞𝚍; 𝚃𝙶: @𝚕𝚊𝚢𝚛𝚢𝚣               "
    ui_print "- Model: $(getprop ro.product.model) "
    ui_print ""
    MODEXTRACT
    ui_print ""
    ui_print "- NOTE -"
if [ "$(settings get system system_locales)" != "ru-RU" ]; then
    su -c settings put system system_locales "ru-RU"
    ui_print "• Third-party system locale detected, setting value to \"ru-RU\""
fi
    ui_print "• If your device is having problems forcing a system locale you don't want - find a fix, for your device"
    ui_print "• When installing the module, the system locale will be forcibly changed to \"ru-RU\""
    ui_print ""
    MODADDON

    ui_print ""
    MODPERM
}

MODEXTRACT() {
    ui_print "- Extracting module files"
    unzip -o "$ZIPFILE" module.prop -d $MODPATH >&2
    unzip -o "$ZIPFILE" system.prop -d $MODPATH >&2
    unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
    unzip -o "$ZIPFILE" 'files/*' -d $MODPATH >&2
}


MODADDON() {
    # List of models that have problems with forced installation of a locale not needed (China/English)
    if [ "$(getprop ro.product.device)" = "TB371FC" ]; then
        ui_print "╔ ▪️ A device has been detected that requires additional patching for module operation."
        if [ -d "/data/adb/modules/ZuiRusLenovo" ]; then
            codename_check
            ui_print "╚ ▪️ A module to fix localization issues for this device has been found."
            ui_print ""
            ui_print "• Thanks to Bunnies, Ichigo, VLAD S and changing for providing the fix."
        else
            codename_check
            ui_print "╚ ▪️ A module to fix localization issues for this device was not found. Please install it."
            ui_print ""
            ui_print "• Up-to-date links to fixes for locale issues for devices on the main repository page in the \"ListLocaleFixes.md\" file".
            ui_print ""
        fi
    fi
    sleep 3
    ui_print "- Successful installation!"
}

# Additional devices-specific overlays to prevent problems
codename_check() {
    if [ "$(getprop ro.product.device)" = "TB371FC" ]; then
        cp -rf $MODPATH/files/additapk/* $MODPATH/system/product/overlay/
        cp -rf $MODPATH/files/vendor/* $MODPATH/system/vendor/
        ui_print "╠ ▪️ This device uses a backup camera overlay for further correct operation."
    fi
    if [ "$(getprop ro.product.device)" = "TBJ716F" ]; then
        rm -f $MODPATH/system/product/overlay/ZuiCamera.apk
        ui_print "╠ ▪️ This device has the camera translated (according to the users), the standard translation is used."
    fi
}

MODPERM() {
    set_perm_recursive $MODPATH 0 0 0755 0644
}

MODSET() {
    sed -i "/description=/c description=${TEXT1}" $MODPATH/module.prop
}


if [ ! "$SKIPUNZIP" = "0" ] ; then
    set -x
    MODPRINT
else
    set +x
    abort
fi

RM_RF
